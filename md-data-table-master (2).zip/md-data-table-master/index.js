// support for Browserify

require('angular-material');
require('./dist/md-data-table');

module.exports = 'md.data.table';
