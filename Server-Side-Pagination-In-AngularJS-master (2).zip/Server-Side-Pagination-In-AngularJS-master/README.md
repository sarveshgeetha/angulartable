# Server-Side-Pagination-In-AngularJS
This tutorial will show us how to implement Server Side Pagination in our AngularJS applications. 

<b>Download</b> --> Click on Download as zip, on your right to download the code.</br>

Demo : http://code.ciphertrick.com/demo/server-pagination/ </br>

Complete Tutorial : - http://code.ciphertrick.com/2015/08/31/server-side-pagination-in-angularjs/
